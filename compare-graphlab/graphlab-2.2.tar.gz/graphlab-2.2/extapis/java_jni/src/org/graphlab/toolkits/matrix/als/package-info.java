/**
 * Contains an implementation of Alternating Least Squares in GraphLab.
 */
package org.graphlab.toolkits.matrix.als;