/**
 * Contains tools for Matrix Factorization.
 */
package org.graphlab.toolkits.matrix;