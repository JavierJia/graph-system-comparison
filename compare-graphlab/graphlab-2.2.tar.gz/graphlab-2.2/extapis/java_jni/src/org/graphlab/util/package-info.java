/**
 * Contains miscellaneous utilities.
 */
package org.graphlab.util;