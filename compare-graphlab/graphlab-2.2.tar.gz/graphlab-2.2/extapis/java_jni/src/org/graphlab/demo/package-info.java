/**
 * Contains a few short examples on GraphLab Java.
 */
package org.graphlab.demo;