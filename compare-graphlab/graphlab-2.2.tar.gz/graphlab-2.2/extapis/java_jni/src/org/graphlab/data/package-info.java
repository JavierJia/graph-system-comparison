/**
 * Provides vertex implementations for JGraphT graphs. All graphs must implement
 * {@link org.graphlab.data.Vertex}.
 */
package org.graphlab.data;