/**
 * Contains convenience toolkits.
 */
package org.graphlab.toolkits;