#ifndef GRAPHLAB_RAPID_JSON_HPP
#define GRAPHLAB_RAPID_JSON_HPP

#include "rapidjson/rapidjson.h"
#include "rapidjson/allocators.h"
#include "rapidjson/reader.h"
#include "rapidjson/writer.h"
#include "rapidjson/document.h"
#include "rapidjson/stringbuffer.h"

#endif